CREATE TABLE users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(45));
INSERT INTO users (username) VALUES ('sai');
INSERT INTO users (username) VALUES ('jo');
INSERT INTO users (username) VALUES ('arun');
CREATE TABLE `orders` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_id` bigint DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK32ql8ubntj5uh44ph9659tiih` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
INSERT INTO `userdb`.`orders`
(`order_id`,
`user_id`)
VALUES
(1,
1);
INSERT INTO `userdb`.`orders`
(`order_id`,
`user_id`)
VALUES
(2,
2);
INSERT INTO `userdb`.`orders`
(`order_id`,
`user_id`)
VALUES
(2,
2);
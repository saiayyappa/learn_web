function myFunc() {
    var x = document.forms.signup.name.value;
    var y = document.forms.signup.password.value;
    var letters = /^[A-Za-z]+$/

    if (x.length == 0) {
        alert("Name is not entered");
        return false;
    } else {
        if (!(x.length >= 2 && x.length <= 30)) {
            alert("Name length should be between 2 and 30");
            return false;
        }

        if (!(x.match(letters))) {
            alert("No numbers/special characters allowed");
            return false;
        }
    }
    if (y.length == 0) {
        alert("Password is not entered");
        return false;
    }
    for (var i = 0; i < document.forms[0].length; i++) {
        if (document.forms['signup'].elements[i].value.length > 0) {
            alert("Details Submitted Successfully");
        }
        return true;
    }

}
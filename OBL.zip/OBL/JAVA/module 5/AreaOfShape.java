import java.util.Scanner;

class Shape {
	protected String shapeName;

	Shape(String shapeName) {
		this.shapeName = shapeName;
	}

	double calculateArea() {
		return 0.0;
	}
}

class Square extends Shape {
	int side;

	Square(int side) {
		super("Square");
		this.side = side;
	}

	public int getSide() {
		return side;
	}

	public void setSide(int side) {
		this.side = side;
	}

	double calculateArea() {
		return side * side;
	}
}

class Rectangle extends Shape {
	int length, breadth;

	Rectangle(int length, int breadth) {
		super("Rectangle");
		this.length = length;
		this.breadth = breadth;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

	double calculateArea() {
		return length * breadth;
	}
}

class Circle extends Shape {
	int radius;

	Circle(int radius) {
		super("Circle");
		this.radius = radius;
	}

	public int getRadius() {
		return radius;
	}

	public void setRadius(int radius) {
		this.radius = radius;
	}

	double calculateArea() {
		return Math.PI * radius * radius;
	}
}

public class AreaOfShape {
	public static void main(String[] args) {

		System.out.println("1. Rectangle \n2. Square \n3. Circle \nArea Calculator --- Choose your shape");
		Scanner sc = new Scanner(System.in);
		int shape;
		double area;
		shape = new Integer(sc.nextInt());

		switch (shape) {
		case 1:
			System.out.println("Enter length and breadth:");
			Rectangle r = new Rectangle(sc.nextInt(), sc.nextInt());
			area = r.calculateArea();
			System.out.printf("Area of Rectangle is: %.2f", area);
			break;
		case 2:
			System.out.println("Enter side:");
			Square sq = new Square(sc.nextInt());
			area = sq.calculateArea();
			System.out.printf("Area of Square is: %.2f", area);
			break;
		case 3:
			System.out.println("Enter Radius:");
			Circle c = new Circle(sc.nextInt());
			area = c.calculateArea();
			System.out.printf("Area of Circle is: %.2f", area);
			break;

		default:
			System.out.println("Please try again");
			break;
		}
		sc.close();
	}
}

import java.util.Scanner;

class Account {
	private String accountNumber;
	private int balance;

	public Account(String accountNumber, int balance) {
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getBalance() {
		return balance;
	}

	public void deposit(int transactionAmount) {
		balance += transactionAmount;
		System.out.println("Your balance after the transaction is: " + balance);
	}

	public void withdraw(int transactionAmount) {
		if (balance < transactionAmount) {
			System.out.println("InSufficient Balance");
			System.out.println("Your balance after the transaction is: " + balance);
		} else if (balance > transactionAmount) {
			balance -= transactionAmount;
			System.out.println("Your balance after the transaction is: " + balance);
		}

	}

}

public class AccountTransaction {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		String accountNumber;
		int balance;
		int transaction;

		System.out.println("Enter the Account Number");
		accountNumber = sc.nextLine();
		System.out.println("Enter the Account Balance");
		balance = sc.nextInt();
		System.out.println("Enter 1 to deposit an amount, 2 to withdraw an account");
		transaction = sc.nextInt();

		Account a = new Account(accountNumber, balance);

		switch (transaction) {
		case 1:
			System.out.println("Enter the amound to deposit");
			int deposit = sc.nextInt();
			a.deposit(deposit);
			break;
		case 2:
			System.out.println("Enter the amound to withdraw");
			int withdraw = sc.nextInt();
			a.withdraw(withdraw);
			break;

		default:
			System.out.println("Please try again");
			break;
		}

		sc.close();
	}

}

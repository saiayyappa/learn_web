import java.util.Scanner;

abstract class Card {

	protected String holderName;
	protected String cardNumber;
	protected String expiryDate;

	public Card(String holderName, String cardNumber, String expiryDate) {
		this.holderName = holderName;
		this.cardNumber = cardNumber;
		this.expiryDate = expiryDate;
	}

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

}

class MembershipCard extends Card {

	private Integer rating;

	public MembershipCard(String holderName, String cardNumber, String expiryDate, Integer rating) {
		super(holderName, cardNumber, expiryDate);
		this.rating = rating;
	}

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

}

class PaybackCard extends Card {

	private Integer pointsEarned;
	private Double totalAmount;

	public PaybackCard(String holderName, String cardNumber, String expiryDate, Integer pointsEarned,
			Double totalAmount) {
		super(holderName, cardNumber, expiryDate);
		this.pointsEarned = pointsEarned;
		this.totalAmount = totalAmount;
	}

	public Integer getPointsEarned() {
		return pointsEarned;
	}

	public void setPointsEarned(Integer pointsEarned) {
		this.pointsEarned = pointsEarned;
	}

	public Double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}

}

public class CardDetails {

	public static void main(String[] args) {
		Integer cardChoice;
		Scanner sc = new Scanner(System.in);

		System.out.println("Select the Card\n1.PayBack Card\n2.Membership Card");
		cardChoice = new Integer(sc.nextLine());

		switch (cardChoice) {
		case 1:
			System.out.println("Enter the Card Details:");
			String cardDetails = sc.nextLine();

			System.out.println("Enter points in card");
			Integer pointsEarned = new Integer(sc.nextLine());

			System.out.println(("Enter Amount"));

			Double totalAmount = new Double(sc.nextDouble());
			String[] details = cardDetails.split("\\|");

			PaybackCard c = new PaybackCard(details[0], details[1], details[2], pointsEarned, totalAmount);

			System.out.println(c.getHolderName() + "'s Payback Card Details:\nCard Number " + c.getCardNumber()
					+ "\nPoints Earned " + c.getPointsEarned() + "\nTotal Amount " + c.getTotalAmount());

			break;
		case 2:
			System.out.println("Enter the Card Details:");
			cardDetails = sc.nextLine();

			System.out.println("Enter rating in card");
			Integer rating = new Integer(sc.nextLine());

			details = cardDetails.split("\\|");

			MembershipCard c1 = new MembershipCard(details[0], details[1], details[2], rating);

			System.out.println(c1.getHolderName() + "'s Membership Card Details:\nCard Number " + c1.getCardNumber()
					+ "\nRating " + c1.getRating());

			break;
		default:
			System.out.println("Please try again...");
			break;
		}
	}

}

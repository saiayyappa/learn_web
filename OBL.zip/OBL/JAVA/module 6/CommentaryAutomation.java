import java.util.Scanner;

class Delivery {

	void displayDeliveryDetails(String bowler, String batsman) {
		System.out.println("Player details of the delivery:\nBowler: " + bowler + "\nBatsman: " + batsman);
	}

	void displayDeliveryDetails(Long runs) {

		if (runs == 4)
			System.out.println("It is a boundary.");
		else if (runs == 6)
			System.out.println("It is a Sixer.");
		else
			System.out.println("Number of runs scored in the delivery: " + runs);
	}
}

public class CommentaryAutomation {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Delivery d = new Delivery();
		System.out.println("Menu\n1.Player details of the delivery\n2.Run details of the delivery");
		int menuChoice = new Integer(sc.nextLine());
		switch (menuChoice) {
		case 1:
			System.out.println("Enter the bowler name");
			String bowler = sc.nextLine();
			System.out.println("Enter the batsman name");
			String batsman = sc.nextLine();
			d.displayDeliveryDetails(bowler, batsman);
			break;
		case 2:
			System.out.println("Enter the number of runs");
			Long runs = new Long(sc.nextLong());
			d.displayDeliveryDetails(runs);
			break;
		default:
			System.out.println("Please try again...");
			break;
		}
		sc.close();
	}

}

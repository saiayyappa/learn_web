
public class Main { 
	public static void main(String[] args) {
		Main m = new Main();
		m.show();
	}
	@Example(add="Hello")
	public void show(){
		Sample s = new Sample();
		System.out.println("show method");
	}
}
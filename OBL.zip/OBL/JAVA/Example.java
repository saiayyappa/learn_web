import static java.lang.annotation.ElementType.METHOD;

import java.lang.annotation.Target;
import java.lang.annotation.Documented;

@Documented
@Target(METHOD)
public @interface Example {
	String add();
}
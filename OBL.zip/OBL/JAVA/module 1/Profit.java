public class Profit{

public static void main(String[] args){
	
	float buyingPrice, sellingPrice;
	buyingPrice = 20.54f;
	sellingPrice = 30.50f;
	
	System.out.println("Buying price is " + buyingPrice);	
	System.out.printf("Selling price is %.2f\n", sellingPrice);

	}
}
package com.sms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.Grizzlydao;
import com.sms.pojo.ManagePojo;

/**
 * Servlet implementation class ManageStockServlet
 */
@WebServlet("/ManageStockServlet")
public class ManageStockServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id1;
		String s=request.getParameter("id");
		int id=Integer.parseInt(s);
		request.setAttribute("id",id);
		
		RequestDispatcher r = request.getRequestDispatcher("Manage.jsp");
		r.forward(request, response);
		String update=request.getParameter("stock");
		int newStock=Integer.parseInt(update);
		id1=Integer.parseInt(request.getParameter("id1"));
		ManagePojo mpojo=new ManagePojo();
		mpojo.setNewStock(newStock);
	
		System.out.println(mpojo.getId());
		System.out.println(mpojo.getNewStock());
		
		
		boolean check=Grizzlydao.manage(mpojo);
		 try {
			  if(check==true)
			  {
					RequestDispatcher rs = request.getRequestDispatcher("InventoryServlet");
					 rs.forward(request, response);
			  }
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	}



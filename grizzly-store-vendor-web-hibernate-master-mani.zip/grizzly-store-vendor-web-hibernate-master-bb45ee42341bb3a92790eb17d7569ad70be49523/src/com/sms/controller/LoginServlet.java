package com.sms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sms.dao.GrizzlyHibernateDao;

import com.sms.dao.Grizzlydao;
import com.sms.dao.ImplementHibernateDao;
import com.sms.pojo.LoginPojo;



/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String user=request.getParameter("user");
		String pass=request.getParameter("pass");
        String useridcheck = null;
        int check=0;
		
        String passwordcheck = null;
        String rolecheck=null;
		
		
		/*LoginPojo lpojo=new LoginPojo();
		lpojo.setUser(user);
		lpojo.setPass(pass);
		String s;
		
		
		int i=HibernateLoginDaoCheck.loginServlet(lpojo);
	   if(i==1)
	   {
		   
		   RequestDispatcher rd=request.getRequestDispatcher("Frame.jsp");
		    rd.forward(request, response);
	   }
	   else if(i==2)
	   {
		   //out.println("<h1> Hi vendor </h1>");
		   RequestDispatcher rd=request.getRequestDispatcher("VendorFrame.jsp");
		    rd.forward(request, response);
	   }
	   else
	   {
		   RequestDispatcher rd=request.getRequestDispatcher("LoginError.html");
	    	rd.forward(request, response);
	   }
		LoginPojo s=HibernateLoginDaoCheck.loginServlet(lpojo);
		if(s!=null)
		{
			out.println("<h1>Hi</h1>");
		}
		else
		{
			out.println("<h1>Sorry</h1>");
		}
	 */
        GrizzlyHibernateDao interfaceObj=new ImplementHibernateDao();
		try
		{
			{
				
				ArrayList<LoginPojo> ad = interfaceObj.fetchLogin();
			   
			       
					
				Iterator iterator = (Iterator) ad.iterator();
					
				while (iterator.hasNext()) 
					
				{
							
			LoginPojo object1 =(LoginPojo)iterator.next();
						
				
					    	  useridcheck= object1.getUser();
				
				    	  passwordcheck=object1.getPass();	
					 
			   	  rolecheck=object1.getRole();
					   
			 	  
				
				    	  if(user.equals(useridcheck) && pass.equals(passwordcheck))
					
			    	  {
					    		  
					    		
			           if(rolecheck.equals("admin"))
					    		 
			 {
					    			
			  check=1;
					    		
			  }
					    		
			  else
					    		
			  {
					    			
			  check=2;
					    		
			  }
					    		
			  break;
					    
				  }
						
			}
					    	  
				       
			}
		}
						
			catch(NullPointerException e)
					
				{
						
				e.printStackTrace();

				
					}
					
			 if(check==1)
			 		{	

						
						 
			 	
				  try
			 		
			  {
					  RequestDispatcher rd=request.getRequestDispatcher("Frame.jsp");
					    rd.forward(request, response);
			 		 
			 }
			 		  catch(NullPointerException p)
			 		 
			 {
			 			  p.printStackTrace();
			 		 
			 }
			 		}
			 		else if(check==2)
			 		
			{
			 			
			 
						try
			 			
			      {
			 			
			        RequestDispatcher rd=request.getRequestDispatcher("VendorFrame.jsp");
				    rd.forward(request, response);
			 		
				}
			 			
			     catch(NullPointerException o)
			 		
				{
			 				
			o.printStackTrace();
			 			
			}
			 		}
			 		
			 		else
			 	   {
			 		   RequestDispatcher rd=request.getRequestDispatcher("LoginError.html");
			 	    	rd.forward(request, response);
			 	   }
	

}
}

package com.sms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.Deletedao;
import com.sms.dao.Grizzlydao;
import com.sms.pojo.ManagePojo;

/**
 * Servlet implementation class ManageServlet
 */
@WebServlet("/ManageServlet")
public class ManageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String s=request.getParameter("id");
		int id=Integer.parseInt(s);
		ManagePojo mpojo=new ManagePojo();
		mpojo.setId(id);
		System.out.println(mpojo.getId());
		
		RequestDispatcher r = request.getRequestDispatcher("Manage.html");
		r.forward(request, response);
		
		
}
}

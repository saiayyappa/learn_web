package com.sms.controller;

import java.io.IOException;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.GrizzlyHibernateDao;

import com.sms.dao.Grizzlydao;
import com.sms.dao.ImplementHibernateDao;

/**
 * Servlet implementation class InventoryServlet
 */
@WebServlet("/InventoryServlet")
public class InventoryServlet extends HttpServlet {
	
	
		   
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			response.getWriter().append("Served at: ").append(request.getContextPath());
			
			//LinkedList detailsVendor = Grizzlydao.fetchVendorProducts();
			//request.setAttribute("detailsVendor", detailsVendor);
			GrizzlyHibernateDao interfaceObj=new ImplementHibernateDao();
			LinkedList detailsVendor=interfaceObj.fetchVendorProducts();
			request.setAttribute("detailsVendor", detailsVendor);
			
			RequestDispatcher r = request.getRequestDispatcher("Inventory.jsp");
			 r.forward(request, response);
		}

	
}

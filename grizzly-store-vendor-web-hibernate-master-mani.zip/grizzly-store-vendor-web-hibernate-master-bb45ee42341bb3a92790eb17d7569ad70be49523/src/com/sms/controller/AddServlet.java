package com.sms.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.GrizzlyHibernateDao;

import com.sms.dao.Grizzlydao;
import com.sms.dao.ImplementHibernateDao;
import com.sms.pojo.InsertProductPojo;


@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		int id=Integer.parseInt(request.getParameter("pid"));
		String pname=request.getParameter("pname");
		String pbrand=request.getParameter("pbrand");
		String pcategory=request.getParameter("pcategory");
		int pprice=Integer.parseInt(request.getParameter("pprice"));
		float prating=Float.parseFloat(request.getParameter("prating"));
     	int pbuffer=Integer.parseInt(request.getParameter("pbuffer"));
     	InsertProductPojo Ipojo=new InsertProductPojo();
     	Ipojo.setPid(id);
     	Ipojo.setProductList(pname);
     	Ipojo.setBrand(pbrand);
     	Ipojo.setCategory(pcategory);
     	Ipojo.setRating(prating);
     	Ipojo.setPrice(pprice);
     	Ipojo.setBuffer(pbuffer);
     	response.setContentType("text/html");
     	/*int j=Grizzlydao.insertProductTable(Ipojo);
     	int k=Grizzlydao.insertInventoryTable(Ipojo);
     	int l=j+k;
     	if(l==3)
     	{
     		  RequestDispatcher rd=request.getRequestDispatcher("FetchProductServlet");
			    rd.forward(request, response);
     	}
     	*/
     	GrizzlyHibernateDao interfaceObj=new ImplementHibernateDao();
     	int j=interfaceObj.insertProductTable(Ipojo);
     	int k=interfaceObj.insertInventoryTable(Ipojo);
     	int l=j+k;
     	if(l==3)
     	{
     		  RequestDispatcher rd=request.getRequestDispatcher("FetchProductServlet");
			    rd.forward(request, response);
     	}
		
		
	}

}

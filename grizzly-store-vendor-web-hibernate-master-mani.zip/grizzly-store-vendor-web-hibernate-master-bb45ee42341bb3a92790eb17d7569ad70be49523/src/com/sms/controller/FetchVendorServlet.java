package com.sms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.GrizzlyHibernateDao;

import com.sms.dao.Grizzlydao;
import com.sms.dao.ImplementHibernateDao;

/**
 * Servlet implementation class FetchVendorServlet
 */
@WebServlet("/FetchVendorServlet")
public class FetchVendorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		//LinkedList detailsVendor = Grizzlydao.fetchVendorProducts();
		//request.setAttribute("detailsVendor", detailsVendor);
		GrizzlyHibernateDao interfaceObj=new ImplementHibernateDao();
		ArrayList detailsVendor=interfaceObj.fetchProducts();
		request.setAttribute("detailsVendor",detailsVendor);
		
		RequestDispatcher r = request.getRequestDispatcher("Products.jsp");
		 r.forward(request, response);
	}

	
	}



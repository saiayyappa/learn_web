package com.sms.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sms.dao.Deletedao;
import com.sms.dao.GrizzlyHibernateDao;

import com.sms.dao.Grizzlydao;
import com.sms.dao.ImplementHibernateDao;
import com.sms.pojo.DeletePojo;
import com.sms.pojo.FetchPojo;



@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String s=request.getParameter("id");
        int id=Integer.parseInt(s);        
       
        DeletePojo spojo=new DeletePojo();
		
		spojo.setId(id);
        //boolean check=Deletedao.delete(spojo);
		GrizzlyHibernateDao interfaceObj=new ImplementHibernateDao();
		boolean check=interfaceObj.delete(spojo);
       
        try {
			  if(check==true)
			  {
					RequestDispatcher r = request.getRequestDispatcher("FetchProductServlet");
					 r.forward(request, response);
			  }
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		

	}

}

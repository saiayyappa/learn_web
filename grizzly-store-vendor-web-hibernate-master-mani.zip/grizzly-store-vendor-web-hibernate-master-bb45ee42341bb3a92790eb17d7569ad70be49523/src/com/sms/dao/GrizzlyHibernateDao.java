package com.sms.dao;

import java.util.ArrayList;
import java.util.LinkedList;

import com.sms.pojo.DeletePojo;
import com.sms.pojo.FetchVendorPojo;
import com.sms.pojo.InsertProductPojo;
import com.sms.pojo.LoginPojo;

public interface GrizzlyHibernateDao {
	
	public  ArrayList fetchProducts();

	public  int insertProductTable(InsertProductPojo ipojo);

	public int insertInventoryTable(InsertProductPojo ipojo);
	public boolean delete(DeletePojo spojo);
	public LinkedList<FetchVendorPojo> fetchVendorProducts();
	public ArrayList<LoginPojo> fetchLogin();
}

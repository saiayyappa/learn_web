package com.sms.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.sms.pojo.DeletePojo;
import com.sms.pojo.FetchVendorPojo;
import com.sms.pojo.InsertProductPojo;
import com.sms.pojo.LoginPojo;

public class ImplementHibernateDao implements GrizzlyHibernateDao {

	@Override
	public ArrayList fetchProducts() {
		try
		{
		ArrayList<FetchVendorPojo> allProducts = new ArrayList<FetchVendorPojo>();
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		List list=session.createQuery("from HibernateVendorProductFetchEntity").list();
		Iterator iterator=list.iterator();
		while(iterator.hasNext())
		{
			HibernateVendorProductFetchEntity entityObj=(HibernateVendorProductFetchEntity)iterator.next();
			FetchVendorPojo  pojoObj=new FetchVendorPojo();
			pojoObj.setId(entityObj.getId());
			pojoObj.setProductList(entityObj.getListProducts());
			pojoObj.setBrand(entityObj.getBrand());
			pojoObj.setPrice(entityObj.getPrice());
			pojoObj.setCatagory(entityObj.getCatagory());
			pojoObj.setRating(entityObj.getRating());
			allProducts.add(pojoObj);
		}
		transaction.commit();
		return allProducts;
		
		}
		catch (HibernateException e) {
			e.printStackTrace();
		}
		return null;// TODO Auto-generated method stub
		
	}

	@Override
	public int insertProductTable(InsertProductPojo ipojo) {
		  int i =1;
	        
	        HibernateVendorProductFetchEntity insertProductEntity=new HibernateVendorProductFetchEntity(ipojo.getPid(),ipojo.getProductList(),ipojo.getBrand(),ipojo.getCategory(),ipojo.getPrice(),ipojo.getRating());
	        SessionFactory sessionFactrory=HibernateUtil.getSessionFactory();
	        Session session=sessionFactrory.openSession();
	        Transaction transaction=session.beginTransaction();
	        session.save(insertProductEntity);
	  transaction.commit();
	        return i;
	}

	@Override
	public int insertInventoryTable(InsertProductPojo ipojo) {
		int j=2;
		HibernateVendorInventoryFetchEntity insertInventoryEntity=new HibernateVendorInventoryFetchEntity(ipojo.getPid(),0,ipojo.getBuffer());
				  SessionFactory sessionFactrory=HibernateUtil.getSessionFactory();
        Session session=sessionFactrory.openSession();
        Transaction transaction=session.beginTransaction();
        session.save(insertInventoryEntity);
  transaction.commit();
        return j;	
	}

	@Override
	public boolean delete(DeletePojo spojo) {
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
        Session session=sessionFactory.openSession();
        Transaction transaction=session.beginTransaction();       
        Query query = session.createQuery("delete HibernateVendorProductFetchEntity where id ='"+spojo.getId()+"'");  

query.executeUpdate();  

transaction.commit(); 
		return true;
	}

	@Override
	public LinkedList<FetchVendorPojo> fetchVendorProducts() {
		LinkedList<FetchVendorPojo> linkedList=new LinkedList<FetchVendorPojo>();
		SessionFactory sessionFactory=HibernateUtil.getSessionFactory();
		Session session=sessionFactory.openSession();
		Transaction transaction=session.beginTransaction();
		List list=session.createQuery("from HibernateVendorProductFetchEntity").list();
		Iterator iterator=list.iterator();
		while(iterator.hasNext())
		{
			HibernateVendorProductFetchEntity proObj=(HibernateVendorProductFetchEntity) iterator.next();
			FetchVendorPojo pojoObj=new FetchVendorPojo();
			pojoObj.setId(proObj.getId());
			pojoObj.setProductList(proObj.getListProducts());
			pojoObj.setBrand(proObj.getBrand());
			pojoObj.setCatagory(proObj.getCatagory());
			pojoObj.setPrice(proObj.getPrice());
			pojoObj.setRating(proObj.getRating());
			pojoObj.setInstock(proObj.getHibenateVendorInventoryFetchEntity().getInStock());
			pojoObj.setBuffer(proObj.getHibenateVendorInventoryFetchEntity().getBuffer());
			linkedList.add(pojoObj);
		}
		
		transaction.commit();
		return linkedList;
	}

	@Override
	public ArrayList<LoginPojo> fetchLogin() {
		ArrayList<LoginPojo> arraylist = new ArrayList<LoginPojo>();
		SessionFactory sessionFactrory=HibernateUtil.getSessionFactory();
		Session session=sessionFactrory.openSession();
		Transaction transaction=session.beginTransaction();
		

		List list=session.createQuery("from HibernateLoginPojoEntity").list();
		Iterator iterator = list.iterator();
		while(iterator.hasNext())
		{

			HibernateLoginPojoEntity obj = (HibernateLoginPojoEntity) iterator.next();
			LoginPojo object=new LoginPojo();
			object.setUser(obj.getUser());
			object.setPass(obj.getPassword());
			object.setRole(obj.getRole());
			arraylist.add(object);
	}
		
		transaction.commit();
		return arraylist;

}
	}



package com.sms.dao;

import javax.persistence.*;

@Entity
@Table(name="login")
public class HibernateLoginPojoEntity {
	
	@Id
	@Column(name="user")
	
	private String user;
	@Column(name="password")
	private String password;
	@Column(name="role")
	private String role;
	
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public HibernateLoginPojoEntity(String user,String password,String role)
	{
		super();
		this.user=user;
		this.password=password;
		this.role=role;
	}
	public HibernateLoginPojoEntity() {
		
	}
	

}

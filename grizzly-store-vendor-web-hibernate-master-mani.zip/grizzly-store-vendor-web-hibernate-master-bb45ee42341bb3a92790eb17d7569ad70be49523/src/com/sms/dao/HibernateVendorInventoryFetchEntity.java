package com.sms.dao;

import javax.persistence.*;

@Entity
@Table(name="inventory")
public class HibernateVendorInventoryFetchEntity {
	@Id
	@Column(name="ID")
	private int id;
	@Column(name="Instock")
	private int inStock;
	@Column(name="Buffer")
	private int buffer;
	@OneToOne(cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn
	private HibernateVendorProductFetchEntity hibernateVendorProductFetchEntity;
	public HibernateVendorProductFetchEntity getHibernateVendorProductFetchEntity() {
		return hibernateVendorProductFetchEntity;
	}
	public void setHibernateVendorProductFetchEntity(HibernateVendorProductFetchEntity hibernateVendorProductFetchEntity) {
		this.hibernateVendorProductFetchEntity = hibernateVendorProductFetchEntity;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getInStock() {
		return inStock;
	}
	public void setInStock(int inStock) {
		this.inStock = inStock;
	}
	public int getBuffer() {
		return buffer;
	}
	public void setBuffer(int buffer) {
		this.buffer = buffer;
	}
	
	public HibernateVendorInventoryFetchEntity(int id, int inStock, int buffer) {
		super();
		this.id = id;
		this.inStock = inStock;
		this.buffer = buffer;
	}
	public HibernateVendorInventoryFetchEntity() {
		super();
		
	}

}

package com.sms.dao;

import javax.persistence.*;

@Entity
@Table(name="products")
public class HibernateVendorProductFetchEntity {
	@Id
	@Column(name="ID")
	private int id;
	@Column(name="ListProducts")
	private String listProducts;
	@Column(name="Brand")
	private String brand;
	@Column(name="Catagory")
	private String catagory;
	@Column(name="Price")
	private int price;
	@Column(name="Rating")
	private float rating;
	@OneToOne(mappedBy ="hibernateVendorProductFetchEntity",cascade=CascadeType.ALL)
	private HibernateVendorInventoryFetchEntity hibenateVendorInventoryFetchEntity;
	public HibernateVendorInventoryFetchEntity getHibenateVendorInventoryFetchEntity() {
		return hibenateVendorInventoryFetchEntity;
	}
	public void setHibenateVendorInventoryFetchEntity(
			HibernateVendorInventoryFetchEntity hibenateVendorInventoryFetchEntity) {
		this.hibenateVendorInventoryFetchEntity = hibenateVendorInventoryFetchEntity;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getListProducts() {
		return listProducts;
	}
	public void setListProducts(String listProducts) {
		this.listProducts = listProducts;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public float getRating() {
		return rating;
	}
	public void setRating(float rating) {
		this.rating = rating;
	}
	public HibernateVendorProductFetchEntity(int id,String listProducts,String brand, String catagory,int price,float rating)
	{
		this.id = id;
		this.listProducts = listProducts;
		this.brand = brand;
		this.catagory = catagory;
		this.price = price;
		this.rating = rating;
	}
	public HibernateVendorProductFetchEntity()
	{
		super();
	}
	
	
	

}

package com.sms.dao;
import com.sms.pojo.*;
import com.sms.controller.*;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;







public class Grizzlydao {
	
	
	/*public static int AddProducts(addProPojo pojo)
	{
		int i = 0;
			try
			{
				
				Connection con=DBUtil.createConnection();
				PreparedStatement ps=con.prepareStatement("insert into protable (Id,Catagory,Name,Description,Price,) values(?,?,?,?,?)");
			     ps.setInt(1,pojo.getId());
			     ps.setString(2,pojo.getCatagory());
			     ps.setString(3,pojo.getProdname());
			     ps.setString(4,pojo.getDescription());
			     ps.setInt(5,pojo.getPrice());
				i=ps.executeUpdate();
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			return i;
	}*/
	public static int loginServlet(LoginPojo lpojo)
	{
		try
		{
			Connection con=DBUtil.createConnection();
			Statement stmt=con.createStatement();
		    ResultSet rs=stmt.executeQuery("Select * from login");
		    
		    while(rs.next())
		    {
		    
		    	if(lpojo.getUser().equals(rs.getString(2))&&lpojo.getPass().equals(rs.getString(3)))
		    	{
		    		if(rs.getString(4).equals("admin"))
		    		{
		    			return 1;
		    		}
		    		if(rs.getString(4).equals("vendor"))
		    		{
		    			return 2;
		    		}
		    	}
		}
		}
		catch (Exception e) {
			e.printStackTrace();
			
		}
		return 0;
	}
	public static ArrayList fetchProducts()
	{
		ArrayList allProducts = new ArrayList();
		Connection con = DBUtil.createConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs=  stmt.executeQuery("select * from products");
			/*while(rs.next())
			{
			    FetchPojo ppojo = new FetchPojo();
				ppojo.setProduct_id(rs.getInt(1));
				ppojo.setProduct_name(rs.getString(2));
				ppojo.setProduct_brand(rs.getString(3));
				ppojo.setProduct_category(rs.getString(4));
				ppojo.setProduct_rating(rs.getFloat(5));
				
				allProducts.add(ppojo);
			}*/
			while(rs.next())
			{
			    FetchPojo ppojo = new FetchPojo();
				ppojo.setProductList(rs.getString(2));
				ppojo.setProductBrand(rs.getString(3));
				ppojo.setProductCatagory(rs.getString(4));
				ppojo.setProductRating(rs.getFloat(6));
				ppojo.setNo(rs.getInt(1));
				
				allProducts.add(ppojo);
			}
		} catch (Exception e) 
		{
			
			e.printStackTrace();
		}
		return allProducts;
		
	}
	
		public static boolean delete(FetchPojo spojo)
		{
			boolean flag=true;
			try
			{
				Connection con=DBUtil.createConnection();
				PreparedStatement ps=con.prepareStatement("delete from products where No=?");
				ps.setInt(1, spojo.getNo());
			
			int i=ps.executeUpdate();
			if(i==1)
				flag=true;

			}
		catch(Exception e)
		{
			flag=false;
		}
		return flag;
		}
		public static LinkedList fetchVendorProducts()
		{
			LinkedList allProducts = new LinkedList();
			Connection con = DBUtil.createConnection();
			Statement stmt;
			try {
				stmt = con.createStatement();
				ResultSet rs=  stmt.executeQuery("select products.ID,products.ListProducts,products.Brand,products.Catagory,products.Price,products.Rating,inventory.Instock,inventory.Buffer from products inner join inventory on products.ID=inventory.ID;");
				
				
				while(rs.next())
				{
				    FetchVendorPojo ppojo = new FetchVendorPojo();
				    ppojo.setId(rs.getInt(1));
				    ppojo.setProductList(rs.getString(2));
				    ppojo.setBrand(rs.getString(3));
				    ppojo.setCatagory(rs.getString(4));
				    ppojo.setPrice(rs.getInt(5));
				    ppojo.setRating(rs.getFloat(6));
				    ppojo.setInstock(rs.getInt(7));
				    ppojo.setBuffer(rs.getInt(8));
					
					allProducts.add(ppojo);
				}
			} catch (Exception e) 
			{
				
				e.printStackTrace();
			}
			return allProducts;
			
		}
		
			public static boolean manage(ManagePojo mpojo)
			{
				boolean flag=true;
				try
				{
					Connection con=DBUtil.createConnection();
					PreparedStatement ps=con.prepareStatement(" UPDATE inventory SET Instock=? WHERE ID=?");
							 
					ps.setInt(1,mpojo.getNewStock());	
					ps.setInt(2,mpojo.getId());
				
				int i=ps.executeUpdate();
				if(i==1)
					flag=true;

				}
			catch(Exception e)
			{
				flag=false;
			}
			return flag;
			}
			public static int insertProductTable(InsertProductPojo ipojo) {
				int i=0;
						try
						{
							Connection con=DBUtil.createConnection();
							PreparedStatement ps=con.prepareStatement("insert into products (ID,ListProducts,Brand,Catagory,Price,Rating) values(?,?,?,?,?,?)");
							ps.setInt(1,ipojo.getPid());
							ps.setString(2,ipojo.getProductList());
							ps.setString(3,ipojo.getBrand());
							ps.setString(4,ipojo.getCategory());
							ps.setInt(5,ipojo.getPrice());
							ps.setFloat(6,ipojo.getRating());
							i=ps.executeUpdate();
							if(i!=0)
							{
								i=1;
							}
							
						}
						catch(Exception e)
						{
							e.printStackTrace();
						}
						
				return i;
			}
			public static int insertInventoryTable(InsertProductPojo ipojo) {
				int j=0;
				try
				{
					Connection con=DBUtil.createConnection();
					PreparedStatement psi=con.prepareStatement("insert into inventory (ID,Instock,Buffer) values(?,0,?) ");
					psi.setInt(1,ipojo.getPid());
					psi.setInt(2,ipojo.getBuffer());
					j=psi.executeUpdate();
					if(j!=0)
					{
						j=2;
					}
				}
					catch(Exception e)
					{
						e.printStackTrace();
					}
					return j;
					
				}
				
			}
	 


	




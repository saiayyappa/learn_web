package com.sms.dao;


	import java.sql.Connection;
	import java.sql.PreparedStatement;

	
import com.sms.pojo.DeletePojo;



	public class Deletedao {
		public static boolean delete(DeletePojo spojo)
		{
			boolean flag=true;
			try
			{
				Connection con=DBUtil.createConnection();
				PreparedStatement ps=con.prepareStatement("delete from list_productstable where No=?");
				ps.setInt(1, spojo.getId());
			
			int i=ps.executeUpdate();
			if(i==1)
				flag=true;

			}
		catch(Exception e)
		{
			flag=false;
		}
		return flag;
		}

	}



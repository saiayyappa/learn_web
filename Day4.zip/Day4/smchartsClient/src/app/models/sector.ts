export class Sector {

    id: number;
    sectorName: String;

    constructor(sectorName, id?) {
        this.sectorName = sectorName;
        this.id = id;
    }
}
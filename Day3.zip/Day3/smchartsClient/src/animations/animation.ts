import { trigger, transition, useAnimation } from '@angular/animations';
import { fadeInDown } from 'ng-animate';

export const animateCards =
    trigger('slideInDown', [transition('* => *', useAnimation(fadeInDown, {
        params: { timing: 1.2 }
      }))])
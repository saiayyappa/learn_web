import { Component, OnInit } from '@angular/core';
import { animateCards } from 'src/animations/animation';

@Component({
  selector: 'manage-ipo',
  templateUrl: './manage-ipo.component.html',
  styleUrls: ['./manage-ipo.component.css'],
  animations: [
    animateCards
  ],
})
export class ManageIpoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CompanyService } from 'src/app/service/company.service';
import { Company } from 'src/app/models/company';
import { SectorService } from 'src/app/service/sector.service';
import { StockExchangeService } from 'src/app/service/stock-exchange.service';
import { Sector } from 'src/app/models/sector';
import { StockExchange } from 'src/app/models/stockExchange';

@Component({
  selector: 'compare-details',
  templateUrl: './compare-details.component.html',
  styleUrls: ['./compare-details.component.css']
})
export class CompareDetailsComponent implements OnInit {

  userId: number;
  companies: Company[];
  sectors: Sector[];
  stockExchanges: StockExchange[];
  generate: boolean = false;
  choice1: String;
  choice2: String;
  choice3: String;
  choice4: String;
  choice5: String;
  choice6: String;
  more: boolean = false;
  finalChoice: String;


  constructor(private router: Router, private companyService: CompanyService, private sectorService: SectorService, private stockExchangeService: StockExchangeService) { }

  ngOnInit() {
    this.companyService.getCompanies().subscribe(async res => {
      this.companies = await res;
    });
    this.sectorService.getSectors().subscribe(async res => {
      this.sectors = await res;
      console.log(this.sectors);
    });
    this.stockExchangeService.getStockExhanges().subscribe(async res => {
      this.stockExchanges = await res;
      console.log(this.stockExchanges);
    });
  }

  onSubmit(choice) {
    this.finalChoice = choice;
    this.generate = true;
  }

  toggleMore() {
    if (this.more == false)
      this.more = true;
    else
      this.more = false;
  }
}

/*Comparison Charts. It should be possible to perform below comparisons of
a.	a single company over different periods of time
b.	different companies over a specific period
c.	a single sector over different periods of time
d.	different sectors over a specific period
e.	between a Sector and a company over a specific period of time
*/

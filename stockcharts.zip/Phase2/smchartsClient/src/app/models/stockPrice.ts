export class StockPrice {

    id: number;
    companyId: number;
    stockExchangeName: String;
    currentPrice: number;
    date: String;
    time: String;

    constructor(companyId?, stockExchangeName?, currentPrice?, date?, time?, id?) {
        this.companyId = companyId;
        this.stockExchangeName = stockExchangeName;
        this.currentPrice = currentPrice;
        this.date = date;
        this.time = time;
        this.id = id;
    }

}